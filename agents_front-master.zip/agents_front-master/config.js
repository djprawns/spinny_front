angular.module('AgentApp.config', [])
.constant('ApiConfig', {

  'backend': 'http://localhost:8081'    // change this as your proxy pass server, see line 59 in config.js 

});
